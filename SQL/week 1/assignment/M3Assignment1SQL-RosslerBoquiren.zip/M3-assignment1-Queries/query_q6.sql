SELECT * FROM actor
WHERE last_name LIKE '%GEN%';
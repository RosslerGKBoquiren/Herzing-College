SELECT * FROM actor
WHERE last_name LIKE '%LI%'
ORDER BY last_name DESC;
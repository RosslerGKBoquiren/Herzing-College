SELECT staff.first_name, staff.last_name, address.address FROM staff
JOIN address ON staff.address_id = address.address_id;

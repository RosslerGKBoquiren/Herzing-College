-- Test: statement should fail
INSERT INTO animals(name, species_id, dob)
VALUES ('George', 5, '2009-02-23 12:54:00');

USE zoo;
-- CREATE new table 'species'
CREATE TABLE species (id INT PRIMARY KEY, current_name VARCHAR(255), latin_name VARCHAR(255), description TEXT) 
ENGINE=InnoDB;

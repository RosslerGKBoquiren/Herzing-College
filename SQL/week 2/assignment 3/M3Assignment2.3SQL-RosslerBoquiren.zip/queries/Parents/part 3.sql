-- Part III - Update animal table with mother and father id
UPDATE animals SET mother_id = 18, father_id = 22 WHERE id = 1;
UPDATE animals SET mother_id = 7, father_id = 21 WHERE id = 10;
UPDATE animals SET mother_id = 41, father_id = 31 WHERE id = 3;
UPDATE animals SET mother_id = 40, father_id = 30 WHERE id = 2;

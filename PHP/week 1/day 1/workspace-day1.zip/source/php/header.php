<!DOCTYPE html>
<html>
<head>
    <title></title>
<style>
body {
	background-color: #ccc;
}
    ul{
        padding:0;
    }

    ul > li{
        list-style:none;
        padding:10px;
    }
</style>
</head>
<body>
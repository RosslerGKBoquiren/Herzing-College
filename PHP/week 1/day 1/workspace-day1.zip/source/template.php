<?php require_once("php/header.php"); ?>
<!-- 
    The contents of the header and footer and brought in by the require_once function. 
    This way when we make changes to our header or footer, we only have to make them in one place.
    We can draw from other files with these functions in php and this can simplify a template such as this one.
-->
<!-- another common function is called include(string $path) -->
<!-- We will use require_once() the main difference is if it tells you if you have an error or not
    Since we want to be aware of errors in our training, we will use require_once() to include separate php files. -->
<div id="content">
    <?php
        echo "Hello World!";
    ?>
</div>
<?php require_once("php/footer.php"); ?>
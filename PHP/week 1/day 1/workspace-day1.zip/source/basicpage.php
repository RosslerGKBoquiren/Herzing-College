﻿<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body style="<?php echo "background-color:#ccc;"; ?>">
    <?php
        echo "Hello World!";
    ?>
</body>
</html>

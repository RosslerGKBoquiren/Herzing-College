<?php require_once("php/header.php"); ?>
<!-- 
    If we want to capture user input, we have to put a form on our page, and place some controls in it.
    We then use a input tag with the type of submit which will trigger sending the form to the server.
    Only controls contained in that form will have their input values captured.
    
    Using method="post" hides the variables from plain sight, but if you use method="get"
    the variables will appear in the address bar in what is called the "query string"
    
    The variables that are captured are accessed with the $_POST or $_GET array depending on 
    what method you choose. For better security use $_POST, otherwise use $_GET for simple tasks.
    We will cover this more in-depth later.
    
    To access the variables submitted, use their name attribute (not id attribute, the id won't work).
-->
<?php 
    if (isset($_POST['btnSubmit'])) //using the isset() function to check to see if the button was pressed.
    {
        //in php you will need to keep track of your opening and closing brackets. { and }
        //these mark a block of code
        
        //we use variables here to store and organize our data.
        //then it is much easier to pass into function parameters. 
        //Below we will do this with the mail function.
        $name = $_POST['name'];
        $email = $_POST['email'];
        $message = $_POST['message'];
        $toaddress = "";
        $fromaddress = "From:"; //From: is required as a message header.
        $subject = "Contact Form Message";
        
        //echo will output to spot in the page where it is located.
        echo $_POST['name'] . "<br/>"; //the dot connects string values together (called concatenation) 
        echo $_POST['email'] . "<br/>"; //the <br> tag is outputting HTML in this case a line break
        echo $_POST['message'] . "<br/>";
        
        //we don't want to echo the btnSubmit, because it doesn't represent anything the user has input.
        
       //Send Email Message - this will only work on a server that has mail set up. 
       //From the basic WAMP installation this will not work, 
       //But on a live web server this is the basic mail function.
       //We will see a warning indicating we cannot send mail. This is ok for now.
       mail($toaddress, $subject, $message, $fromaddress);
       
       
    }
?>
<div id="content">
    <form method="post" id="form1">
        <ul>
            <li>Name: <input type="text" name="name" id="name" /></li>
            <li>Email: <input type="text" name="email" id="email" /></li>           
            <li>Message: <textarea name="message" id="message" col="50" row="4"> </textarea></li>
            <li><input type="submit" name="btnSubmit" id="btnSubmit" value="Send Values!" /></li>
        </ul>
    </form>
</div>
<?php require_once("php/footer.php"); ?>
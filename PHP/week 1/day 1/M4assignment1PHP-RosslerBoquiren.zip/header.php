<!DOCTYPE html>
<html lang="en">
<head>
	<title>Template</title>
	<style>
		body {
			background-color: #ccc;
		}
	</style>
</head>
<body>

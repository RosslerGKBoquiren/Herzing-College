<!DOCTYPE html>
<html lang="en">
<head>
	<title>Basic Page</title>
</head>
<body style="<?php echo "background-color: #ccc"; ?>">
<?php
echo "Hello, World!";
?>
</body>

</html>


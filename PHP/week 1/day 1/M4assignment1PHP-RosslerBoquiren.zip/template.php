<?php require_once("header.php"); ?>
<?php
echo "Hello, World!";
?>
<?php require_once("footer.php"); ?>

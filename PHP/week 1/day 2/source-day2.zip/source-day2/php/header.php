<!DOCTYPE html>
<html>
<head>
    <title></title>
<style>
    ul{
        padding:0;
    }

    ul > li{
        list-style:none;
        padding:10px;
    }
</style>
</head>
<body>
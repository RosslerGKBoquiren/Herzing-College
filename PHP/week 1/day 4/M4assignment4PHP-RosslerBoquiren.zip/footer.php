</body>
	<div id="footer-div">
        <p>&copy; <?php echo date("Y"); ?> Rossler Boquiren</p>
    </div>
</html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Ask For Province</title>

<style>
*{
	color:white;
	background:#000000;
	font-size:24px;
}

#container{
	border-left:dotted 6px #666666;
	border-right:dotted 6px #CCCCCC;
	border-top:dotted 6px #FFFFFF;
	border-bottom:dotted 6px #333333;
	padding:20px;
	border-radius:20px;
	/*width:500px;*/
}
#province{
	display:block;
}
input[type="submit"]{
	display:block;
	margin: 10px;
border: 1px solid #fff;
}
select {
margin: 10px;
}

</style>

</head>
<body>
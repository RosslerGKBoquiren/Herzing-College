﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment7
{
    class Embassy
    {
        public string address;
        public string ambassador;
        public long telephoneNumber;
    }
}

//Called to fade element
function fade(element)
{
  //We will fade the object in 10 steps
  var steps = 10;

  //Set the starting opacity
  setOpacity(element, 1);

  //Loops the timer function
  for(i=0; i<steps; ++i) {
    setTimeout(function(){fadeCallback(element);}, (30*i));
  }
}

//Callback to timer function
function fadeCallback(element)
{
  //Get the current opacity
  var opacity=getOpacity(element);

  //Set the new opacity
  setOpacity(element, opacity-0.1);
}

//Gets an element's opacity
function getOpacity(element)
{
  var opacity = null;

  opacity = element.style.opacity;
 
  return opacity;
}

//Sets an element's opacity
function setOpacity(element, o)
{
 
    element.style.opacity = o;
	//alert message for practice purposes and to observe the changes in opacity
		alert(o);

}


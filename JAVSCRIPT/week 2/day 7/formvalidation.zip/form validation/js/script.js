function validateForm() {
    //get fields from myform by the name attribute
	//var email = document.getElementsByName("email").value;
	//OR:
	var email = document.forms["myform"]["email"].value;
	//var age = document.getElementsByName("age").value;
	//OR:
    var age = document.forms["myform"]["age"].value;

    //do validation
    if (email == null || email == "") {
        alert("Email must be filled out");
        return false;
    }

    if (age == null || age == "") { //null check along with blank string "" check is good for cross browser compatibility
        alert("Age must be filled out");
        return false;
    } else if (isNaN(age)) {
        alert("Age must be numeric");
		document.forms["myform"]["age"].value = '';
        return false;
    }

    var selected = "none selected";
    var radiogroup = document.forms["myform"]["choices"];
    //var radiogroup = document.getElementsByName("choices");
    for (var i = 0; i < radiogroup.length; i++) {
        if (radiogroup[i].checked) {
            selected = radiogroup[i].value;
        }
    }

    alert(selected);

    var a = parseInt(age);
	if (selected != "none selected"){ 
		alert(`Form is valid. Email is: ${email}. Age doubled is : ${a * 2}. Color is: ${selected}`);
		return true;
	}else {
		alert("Choose a color.");
		return false;
	}
	
	
}

function showClickedValue(color) {
    alert("Your eye color is : " + color);
}
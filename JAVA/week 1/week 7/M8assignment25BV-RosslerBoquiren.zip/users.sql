-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 02, 2024 at 04:43 AM
-- Server version: 8.2.0
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `address` varchar(255) NOT NULL,
  `province` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `gender`, `address`, `province`, `country`, `phone`) VALUES
(1, 'John', 'Test@gmail.com', '123456', 'Female', 'Test Ave', 'Nunavut', 'Canada', '(514) 691-0810'),
(2, 'James', 'testing@gmail.com', '456789', 'Male', 'North Ave', 'Nunavut', 'Canada', '(514) 841-1224'),
(3, 'Jane', 'jane@gmail.com', '789456', 'Female', 'Corn street', 'Manitoba', 'WestCan', '(438) 741-1258'),
(4, 'Ross', 'ross@gmail.com', '123456', 'Male', 'Ross Ave', 'Quebec', 'Canada', '(514) 852-1447'),
(5, 'James', 'James@gmail.com', 'pass654', 'Male', 'James Ave', 'Northwest Territories', 'Canada', '(514) 741-1225'),
(6, 'Assignment25', 'test25@gmail.com', 'pass789456', 'Female', 'Assignment25 Ave', 'Quebec', 'Canada', '(514) 852-2114');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

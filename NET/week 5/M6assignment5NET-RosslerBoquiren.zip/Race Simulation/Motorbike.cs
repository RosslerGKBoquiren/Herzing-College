﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Race_Simulation
{
    public class Motorbike : Vehicle
    {
        /// <summary>
        /// Represents a Motorbike, inheriting from the Vehicle class
        /// </summary>
        public int Acceleration { get; set; }

        public Motorbike(string name, string color, int speed, int acceleration)
            : base(name, color, speed)
        {
            Acceleration = acceleration;
        }

        /// <summary>
        /// Calculates the movement progress of the car based on its speed and acceleration
        /// </summary>
        /// <returns>Progress bar's value calculated based on speed and acceleration</returns>
        public override int Move()
        {
            return Speed + (Acceleration / 2); 
        }
    }

}

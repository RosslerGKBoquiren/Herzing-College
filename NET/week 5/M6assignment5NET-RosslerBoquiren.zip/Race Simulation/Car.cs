﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Race_Simulation
{
    /// <summary>
    /// Represents a Car, inheriting from the Vehicle class
    /// </summary>
    public class Car : Vehicle
    {
        public int Acceleration { get; set; }

        public Car(string name, string color, int speed, int acceleration)
            : base(name, color, speed)
        {
            Acceleration = acceleration;
        }

        /// <summary>
        /// Calculates the movement progress of the car based on its speed and acceleration
        /// </summary>
        /// <returns>Progress bar's value calculated based on speed and acceleration</returns>
        public override int Move()
        {
            return Speed + (Acceleration / 2); 
        }
    }

}

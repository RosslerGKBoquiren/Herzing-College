using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Race_Simulation
{
    public partial class Form1 : Form
    {
        // Queue to hold vehicle instances
        private Queue<Vehicle> vehicleQueue;

        // Single instances of each vehicle
        private Car laFerrari;
        private Motorbike streetFighterV4;
        private Bicycle contendSL1;
        private Truck tundra;

        public Form1()
        {
            InitializeComponent();
            InitializeVehicles();
            InitializeVehicleControls();
        }

        // Initialize vehicles with their properties
        private void InitializeVehicles()
        {
            laFerrari = new Car("LaFerrari", "Red", 150, 10);
            streetFighterV4 = new Motorbike("StreetFighter V4", "Black", 140, 15);
            contendSL1 = new Bicycle("Contend SL1", "Orange", 70, -1);
            tundra = new Truck("Tundra", "White", 130);
        }

        // Initialize the vehicle controls (ProgressBar)
        private void InitializeVehicleControls()
        {
            vehicleQueue = new Queue<Vehicle>();

            // Reset progress bars
            progressBarCar.Value = 0;
            progressBarMotorbike.Value = 0;
            progressBarBicycle.Value = 0;
            progressBarTruck.Value = 0;
        }

        // Start the race
        private void buttonStartRace_Click(object sender, EventArgs e)
        {
            vehicleQueue.Clear(); // Clear any existing vehicles in the queue

            // Update labels with vehicle names and change label colors based on vehicle color
            labelCar.Text = laFerrari.Name;
            labelCar.ForeColor = Color.Red; 

            labelMotorbike.Text = streetFighterV4.Name;
            labelMotorbike.ForeColor = Color.Yellow; 

            labelBicycle.Text = contendSL1.Name;
            labelBicycle.ForeColor = Color.Orange; 

            labelTruck.Text = tundra.Name;
            labelTruck.ForeColor = Color.White; 

            // Enqueue vehicles
            EnqueueVehicle(laFerrari, progressBarCar);
            EnqueueVehicle(streetFighterV4, progressBarMotorbike);
            EnqueueVehicle(contendSL1, progressBarBicycle);
            EnqueueVehicle(tundra, progressBarTruck);

            raceTimer.Start();
        }

        
        // Enqueue vehicle and calculate its initial progress
        private void EnqueueVehicle(Vehicle vehicle, ProgressBar progressBar)
        {
            int progressValue = vehicle.Speed;

            // Check if the vehicle has an Acceleration property
            if (vehicle is Car car)
            {
                progressValue += (car.Acceleration / 2);
            }
            else if (vehicle is Motorbike motorbike)
            {
                progressValue += (motorbike.Acceleration / 2);
            }
            else if (vehicle is Bicycle bicycle)
            {
                progressValue += (bicycle.Acceleration / 2);
            }

            vehicleQueue.Enqueue(vehicle);
            progressBar.Value = Math.Min(progressBar.Value + progressValue, 100);
        }

        // Timer event to simulate the race
        private void raceTimer_Tick(object sender, EventArgs e)
        {
            foreach (Vehicle vehicle in vehicleQueue)
            {
                ProgressBar progressBar = GetProgressBar(vehicle);
                int progressValue = vehicle.Speed;

                // Set label color based on vehicle type and color
                if (vehicle is Car car)
                {
                    labelCar.ForeColor = Color.Red; 
                    progressValue += (car.Acceleration / 2);
                }
                else if (vehicle is Motorbike motorbike)
                {
                    labelMotorbike.ForeColor = Color.Yellow; 
                    progressValue += (motorbike.Acceleration / 2);
                }
                else if (vehicle is Bicycle bicycle)
                {
                    labelBicycle.ForeColor = Color.Orange; 
                    progressValue += (bicycle.Acceleration / 2);
                }
                else if (vehicle is Truck truck)
                {
                    labelTruck.ForeColor = Color.White; 
                }

                progressBar.Value = Math.Min(progressBar.Value + progressValue, 100);

                if (progressBar.Value >= 100)
                {
                    DeclareWinner(vehicle.Name);
                    break;
                }
            }
        }

        // Get the corresponding ProgressBar based on the vehicle type
        private ProgressBar GetProgressBar(Vehicle vehicle)
        {
            if (vehicle is Car) return progressBarCar;
            if (vehicle is Motorbike) return progressBarMotorbike;
            if (vehicle is Bicycle) return progressBarBicycle;
            return progressBarTruck; 
        }

        // Declare the winner
        private void DeclareWinner(string vehicleName)
        {
            raceTimer.Stop(); 
            labelWinner.Text = $"{vehicleName} IS THE WINNER!!!";
            buttonStartRace.Enabled = false; 
        }

        // Reset the race
        private void buttonResetRace_Click(object sender, EventArgs e)
        {
            raceTimer.Stop(); // Stop the timer

            progressBarCar.Value = 0;
            progressBarMotorbike.Value = 0;
            progressBarBicycle.Value = 0;
            progressBarTruck.Value = 0;

            labelCar.Text = "Car";
            labelCar.ForeColor = Color.White; 

            labelMotorbike.Text = "Motorbike";
            labelMotorbike.ForeColor = Color.White; 

            labelBicycle.Text = "Bicycle";
            labelBicycle.ForeColor = Color.White; 

            labelTruck.Text = "Truck";
            labelTruck.ForeColor = Color.White; 

            // Reset winner label and enable start button
            labelWinner.Text = "Waiting for the race to finish...";
            buttonStartRace.Enabled = true;

            // Clear the vehicle queue to prepare for a new race
            vehicleQueue.Clear();
        }

    }
}

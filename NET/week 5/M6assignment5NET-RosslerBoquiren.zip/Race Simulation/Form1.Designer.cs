﻿namespace Race_Simulation
{
    partial class Form1
    {

        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            progressBarCar = new ProgressBar();
            progressBarBicycle = new ProgressBar();
            progressBarTruck = new ProgressBar();
            progressBarMotorbike = new ProgressBar();
            labelCar = new Label();
            labelBicycle = new Label();
            labelTruck = new Label();
            labelMotorbike = new Label();
            buttonStartRace = new Button();
            raceTimer = new System.Windows.Forms.Timer(components);
            buttonResetRace = new Button();
            labelWinner = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // progressBarCar
            // 
            progressBarCar.BackColor = Color.DimGray;
            progressBarCar.ForeColor = Color.Gray;
            progressBarCar.Location = new Point(189, 158);
            progressBarCar.Name = "progressBarCar";
            progressBarCar.Size = new Size(404, 43);
            progressBarCar.TabIndex = 0;
            // 
            // progressBarBicycle
            // 
            progressBarBicycle.BackColor = Color.DimGray;
            progressBarBicycle.ForeColor = Color.Gray;
            progressBarBicycle.Location = new Point(189, 267);
            progressBarBicycle.Name = "progressBarBicycle";
            progressBarBicycle.Size = new Size(404, 43);
            progressBarBicycle.TabIndex = 1;
            // 
            // progressBarTruck
            // 
            progressBarTruck.BackColor = Color.DimGray;
            progressBarTruck.ForeColor = Color.Gray;
            progressBarTruck.Location = new Point(189, 385);
            progressBarTruck.Name = "progressBarTruck";
            progressBarTruck.Size = new Size(404, 43);
            progressBarTruck.TabIndex = 2;
            // 
            // progressBarMotorbike
            // 
            progressBarMotorbike.BackColor = Color.DimGray;
            progressBarMotorbike.ForeColor = Color.Gray;
            progressBarMotorbike.Location = new Point(189, 496);
            progressBarMotorbike.Name = "progressBarMotorbike";
            progressBarMotorbike.Size = new Size(404, 43);
            progressBarMotorbike.TabIndex = 3;
            // 
            // labelCar
            // 
            labelCar.AutoSize = true;
            labelCar.BackColor = Color.Transparent;
            labelCar.Font = new Font("Showcard Gothic", 20.25F, FontStyle.Italic);
            labelCar.ForeColor = Color.White;
            labelCar.Location = new Point(189, 204);
            labelCar.Name = "labelCar";
            labelCar.Size = new Size(66, 33);
            labelCar.TabIndex = 4;
            labelCar.Text = "Car";
            // 
            // labelBicycle
            // 
            labelBicycle.AutoSize = true;
            labelBicycle.BackColor = Color.Transparent;
            labelBicycle.Font = new Font("Showcard Gothic", 20.25F, FontStyle.Italic);
            labelBicycle.ForeColor = Color.White;
            labelBicycle.Location = new Point(189, 313);
            labelBicycle.Name = "labelBicycle";
            labelBicycle.Size = new Size(124, 33);
            labelBicycle.TabIndex = 5;
            labelBicycle.Text = "Bicycle";
            // 
            // labelTruck
            // 
            labelTruck.AutoSize = true;
            labelTruck.BackColor = Color.Transparent;
            labelTruck.Font = new Font("Showcard Gothic", 20.25F, FontStyle.Italic);
            labelTruck.ForeColor = Color.White;
            labelTruck.Location = new Point(189, 431);
            labelTruck.Name = "labelTruck";
            labelTruck.Size = new Size(104, 33);
            labelTruck.TabIndex = 6;
            labelTruck.Text = "Truck";
            // 
            // labelMotorbike
            // 
            labelMotorbike.AutoSize = true;
            labelMotorbike.BackColor = Color.Transparent;
            labelMotorbike.Font = new Font("Showcard Gothic", 20.25F, FontStyle.Italic);
            labelMotorbike.ForeColor = Color.White;
            labelMotorbike.Location = new Point(189, 542);
            labelMotorbike.Name = "labelMotorbike";
            labelMotorbike.Size = new Size(174, 33);
            labelMotorbike.TabIndex = 7;
            labelMotorbike.Text = "Motorbike";
            // 
            // buttonStartRace
            // 
            buttonStartRace.BackColor = Color.Transparent;
            buttonStartRace.BackgroundImageLayout = ImageLayout.None;
            buttonStartRace.Cursor = Cursors.Hand;
            buttonStartRace.FlatAppearance.BorderColor = Color.LightGreen;
            buttonStartRace.FlatAppearance.BorderSize = 3;
            buttonStartRace.FlatStyle = FlatStyle.Flat;
            buttonStartRace.Font = new Font("Showcard Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonStartRace.ForeColor = Color.LimeGreen;
            buttonStartRace.Location = new Point(233, 633);
            buttonStartRace.Name = "buttonStartRace";
            buttonStartRace.Size = new Size(160, 48);
            buttonStartRace.TabIndex = 8;
            buttonStartRace.Text = "START";
            buttonStartRace.UseVisualStyleBackColor = false;
            buttonStartRace.Click += buttonStartRace_Click;
            // 
            // raceTimer
            // 
            raceTimer.Enabled = true;
            raceTimer.Tick += raceTimer_Tick;
            // 
            // buttonResetRace
            // 
            buttonResetRace.BackColor = Color.Transparent;
            buttonResetRace.FlatAppearance.BorderColor = Color.DarkGray;
            buttonResetRace.FlatAppearance.BorderSize = 3;
            buttonResetRace.FlatStyle = FlatStyle.Flat;
            buttonResetRace.Font = new Font("Showcard Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttonResetRace.ForeColor = Color.DarkGray;
            buttonResetRace.Location = new Point(399, 633);
            buttonResetRace.Name = "buttonResetRace";
            buttonResetRace.Size = new Size(162, 47);
            buttonResetRace.TabIndex = 9;
            buttonResetRace.Text = "RESET";
            buttonResetRace.UseVisualStyleBackColor = false;
            buttonResetRace.Click += buttonResetRace_Click;
            // 
            // labelWinner
            // 
            labelWinner.AutoSize = true;
            labelWinner.BackColor = Color.Transparent;
            labelWinner.Font = new Font("Showcard Gothic", 26.25F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelWinner.ForeColor = Color.White;
            labelWinner.Location = new Point(96, 708);
            labelWinner.Name = "labelWinner";
            labelWinner.Size = new Size(647, 44);
            labelWinner.TabIndex = 10;
            labelWinner.Text = "\"Waiting for the race to finish...\"";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Showcard Gothic", 48F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(66, 40);
            label1.Name = "label1";
            label1.Size = new Size(659, 79);
            label1.TabIndex = 11;
            label1.Text = "Racing Simulation";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.MediumOrchid;
            BackgroundImage = Properties.Resources._1000_F_523308678_jPNb5PjddaOB7xKcU44PIqTOYipmEZmw;
            ClientSize = new Size(795, 792);
            Controls.Add(label1);
            Controls.Add(labelWinner);
            Controls.Add(buttonResetRace);
            Controls.Add(buttonStartRace);
            Controls.Add(labelMotorbike);
            Controls.Add(labelTruck);
            Controls.Add(labelBicycle);
            Controls.Add(labelCar);
            Controls.Add(progressBarTruck);
            Controls.Add(progressBarBicycle);
            Controls.Add(progressBarCar);
            Controls.Add(progressBarMotorbike);
            Name = "Form1";
            Text = "Form1";
            //Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ProgressBar progressBarCar;
        private ProgressBar progressBarBicycle;
        private ProgressBar progressBarTruck;
        private ProgressBar progressBarMotorbike;
        private Label labelCar;
        private Label labelBicycle;
        private Label labelTruck;
        private Label labelMotorbike;
        private Button buttonStartRace;
        private System.Windows.Forms.Timer raceTimer;
        private Button buttonResetRace;
        private Label labelWinner;
        private Label label1;
    }
}

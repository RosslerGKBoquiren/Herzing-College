﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Race_Simulation
{
    /// <summary>
    /// Represents a Truck, inheriting from the Vehicle class
    /// </summary>
    public class Truck : Vehicle
    {
        public Truck(string name, string color, int speed)
            : base(name, color, speed)
        {
        }


        /// <summary>
        /// Calculates the movement progress of the car based on its speed
        /// </summary>
        public override int Move()
        {
            return Speed; 
        }
    }

}
